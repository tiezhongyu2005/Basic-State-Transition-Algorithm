function y = Sphere(x)
% Sphere function
% Last updated by Ahmed Tawfik (Apr. 30, 2013).
% -100 <= x <= 100
y = sum(x.^2);