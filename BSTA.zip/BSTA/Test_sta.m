clear all
clc
currentFolder = pwd;
addpath(genpath(currentFolder))
% parameter setting
warning('off')
SE =  30; % degree of search enforcement
Dim = 100;% dimension
Range = repmat([-5.12;5.12],1,Dim);%range
Iterations = 1e2*Dim;% maximum number of iterations
tic
[Best,fBest,history] = STA(@Rastrigin,SE,Dim,Range,Iterations);
toc
semilogy(history,'b-o')